<html>
<title>
	Download
</title>
<head>
	Download File !!!
</head>

<form name="form3" method="POST">
<body>
<table align="center">
<tr><td>
<a href="hacking.zip"> Click to Download !!! </a>
</td></tr>
</table>
</form>
</body>
</html>