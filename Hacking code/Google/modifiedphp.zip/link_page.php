<html>
<title>
	Google
</title>
<head>
<table bgcolor="black">
<tr><td>
	<Font Color="grey">
	   +Manoj   Search   Image   Maps   Play   YouTube   News   Gmail   Drive   Calendar   More
</td></tr>
<tr><td>
<b>
	<Font Color="Green">
	Google <Input Type="Text" Name="txtbox" value="Free application download" size="100" Maxlength="100">
</b>
</td></tr>
</table>
</head>

<form name="form2" method="POST">
<body>

<?php
echo "<br>";
echo "About 507,000,000 results (0.21 seconds)";
?>

<table bgcolor="pink">
<tr><td>

<?php 
echo "Ad related to free applications download"."<br>";

    echo "Apps on Google Play - play.google.com"."<br>";
    echo "play.google.com/about/apps"."<br>";
    echo "Download free apps instantly to your Android phone or tablet."."<br>";
    echo "3,501 people +1'd this page"."<br>";
?>

</td></tr>
</table>

<table>
<tr><td>

<?php	echo "<br>";	?>

<a href="//localhost/download.php"> MOBANGO - Free mobile applications, games, themes, ringtones ..... </a>
<Font Color="green">

<?php    echo "<br>"."www.mobango.com/"."<br>";	?>
	<Font Color="black">
<?php
         echo "Download 100% free mobile applications, apps, games, themes, ringtones, tunes,"."<br>";
         echo "music, fulltracks, polytunes, polytones, wallpapers, images, animations, ..."."<br>";
	     echo "<br>";
?>

<a href="//localhost/download.php"> Download free apps & games for your mobile on Zedge </a>
<Font Color="green">

<?php	echo "<br>"."www.zedge.net/apps-games/"."<br>";	?>
	<Font Color="black">
<?php
    echo "Large selection of free apps and games for Nokia, Samsung, Motorola, HTC,"."<br>";
    echo "Blackberry, Sony Ericsson, LG and many more."."<br>";
	echo "<br>";
?>  

<a href="//localhost/download.php"> The Best Free Apps - Free application - Download Free software </a>
<Font Color="green">

<?php    echo "<br>"."www.thebestapplications.com/"."<br>";	?>
	<Font Color="black">
<?php
    echo "More than 100 Free apps and software for Windows and Mac. Download the best"."<br>";
    echo "freeware for Windows and Mac."."<br>";
    echo "Image Clock - Bean - Zoundry Raven - iTunes"."<br>";
	echo "<br>";
?>

<a href="//localhost/download.php > CNET Download.com: Free software downloads and software reviews </a>
<Font Color="green">

<?php	echo "<br>"."download.cnet.com/"."<br>";	?>
	<Font Color="black">

<?php
    echo "CNET Download.com provides free downloads for Windows, Mac, iOS and Android"."<br>"; 
    echo "computers and mobile devices. Every category of desktop software and ..."."<br>";
	echo "<br>";
?>

<a href="//localhost/download.php"> FileHippo.com - Download Free Software </a>
<Font Color="green">

<?php	echo "<br>"."www.filehippo.com/"."<br>";	?>
	<Font Color="black">
<?php
    echo "Contains freeware, demo and shareware programs to download in several categories."."<br>";
    echo "Also features latest updates and most popular downloads."."<br>";
	echo "<br>";
?>
   
<a href="//localhost/download.php"> Download Free Apps:Download Latest Desktop PC Applications for ... </a>
<Font Color="green">

<?php	echo "<br>"."www.in.com/downloads/softwares-recently_added-1.html"."<br>";	?>
	<Font Color="black">

<?php
    echo "Download Latest Software - Huge collection of Free Software downloads. Download "."<br>";
    echo "free Softwares applications for your PC Desktop computers, Laptop, Mobile ..."."<br>";
	echo "<br>";
?>

<a href="//localhost/download.php"> WAPTRICK Download Best Free Applications </a>
<Font Color="green">

<?php	echo "<br>"."waptrick.com/applications/"."<br>";	?>
	<Font Color="black">

<?php
    echo "Download best quality of free android apps for Android, Symbian, Blackberry, iPhone "."<br>";
    echo "and tablets. All of these free apps are tested and working."."<br>";
	echo "<br>";
?>

<a href="//localhost/download.php"> Download Free Mobile Phone Games - Your Free and Legal Source ... </a>
<Font Color="green">

<?php	echo "<br>"."www.mobilerated.com/"."<br>";	?>
	<Font Color="black">

<?php
    echo "Downloadable free mobile phone games, online java games for mobiles. Download"."<br>";
    echo "free cellular Nokia games, Samsung java games, Motorola java games, free ..."."<br>";
	echo "<br>";
?>

<a href="//localhost/download.php"> AppHit.com - Download Free Software </a>
<Font Color="green">

<?php    echo "<br>"."www.apphit.com/"."<br>";	?>
	<Font Color="black">

<?php
    echo "Latest Update. Feb 27: Ad-Aware Free Antivirus+ 10.5.1.4369; Feb 27: Fraps 3.5.99; "."<br>";
    echo "Feb 27: uTorrent 3.3.1 Beta 29213; Feb 27: Google Chrome 27.0.1423.0 .."."<br>";
	echo "<br>";
?>

<u><b>
<?php
echo "Searches related to free applications download"."<br>";
	echo "<br>";

?>
</u></b>
</td></tr>

<tr><td>	<a href="//localhost/download.php"> free applications download for pc </a>	</td></tr>
<tr><td>	<a href="//localhost/download.php"> free applications download for mobile </a>	</td></tr>
<tr><td>	<a href="//localhost/download.php">free phone applications download </a>	</td></tr>
<tr><td>	<a href="//localhost/download.php">free applications download for android </a>	</td></tr>
<tr><td>	<a href="//localhost/download.php">blackberry free applications download </a>	</td></tr>
<tr><td>	<a href="//localhost/download.php">free applications download for nokia x2-01 </a>	</td></tr>
<tr><td>	<a href="//localhost/download.php">iphone 4s free applications download </a>	</td></tr>
<tr><td>	<a href="//localhost/download.php">samsung galaxy note free applications download </a>	</td></tr>

</table>
</form>
</body>
</html>